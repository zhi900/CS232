int main() {
    int a=13,b=5, c=0;
    if(a >6) {
        c += 2;
    } else {
        c -= 2;
    }
}
