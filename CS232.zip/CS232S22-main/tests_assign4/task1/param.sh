#!/bin/bash
expected="uppercase.c"
