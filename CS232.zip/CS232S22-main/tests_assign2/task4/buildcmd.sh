#!/bin/bash
cmd="gcc -Wall -std=c11 prime_test_buggy.c -o prime_test"
executable="prime_test"
