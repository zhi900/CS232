#!/bin/bash
expected="arith_until.c"
