#!/bin/bash
cmd="gcc -Wall -std=c11 arith.c -o arith"
executable="arith"
