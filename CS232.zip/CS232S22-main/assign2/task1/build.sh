
cd  assign2/task1
gcc -std=c11 -Wall intro.c 
./a.out
gcc -std=c11 -Wall intro.c -o intro
./intro < intro.in > intro.out