#!/bin/bash
cmd="gcc -Wall -std=c11 mem_bug1.c -o mem_bug1"
executable="mem_bug1"
