#!/bin/bash
cmd="gcc -Wall -std=c11 get_bits.c test_get_bits.c -o test_get_bits"
executable="test_get_bits"
